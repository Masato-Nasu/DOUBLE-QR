"""Reproducible synthetic experiments. These are never smartphone measurements."""
import hashlib
import importlib.metadata
import io
import math
import platform
import time
from datetime import datetime, timezone
import cv2
import numpy as np
from PIL import Image, ImageFilter
from engine import (build, make_image, decode, decode_zxing, read, DATA_SLOTS,
                    base_qr, rs_metrics)

CASES = ('original', 'resize', 'blur', 'jpeg', 'perspective', 'noise')
LABELS = dict(original='元PNG', resize='縮小', blur='ぼかし', jpeg='JPEG圧縮', perspective='遠近変形', noise='縮小＋ノイズ')


def metadata(kind, seed):
    return dict(kind=kind, evidence='自動テスト：合成画像。スマートフォン実機ではありません。',
                measured_at=datetime.now(timezone.utc).isoformat(), seed=seed,
                environment={'python':platform.python_version(), 'platform':platform.platform(),
                **{p:importlib.metadata.version(p) for p in ('qrcode','opencv-python-headless','zxing-cpp','numpy','Pillow')}},
                qr=dict(version=12, correction='H', mask=0, box_size=14, border=6))


def wilson(success, total):
    if not total:
        return None
    z = 1.95996398454
    p = success / total
    den = 1 + z*z/total
    mid = (p+z*z/(2*total))/den
    delta = z*math.sqrt(p*(1-p)/total+z*z/(4*total*total))/den
    return [round(100*(mid-delta),2),round(100*(mid+delta),2)]


def rate(values):
    values = list(values)
    n, s = len(values), sum(bool(v) for v in values)
    return dict(success=s, trials=n, percent=round(100*s/n,2) if n else None,
                wilson95_percent=wilson(s,n))


def parameters(case, seed):
    rng = np.random.default_rng(seed)
    if case == 'original': return {}
    if case == 'resize': return {'pixels':int(rng.integers(210,421))}
    if case == 'blur': return {'radius':round(float(rng.uniform(0.7,2.8)),3)}
    if case == 'jpeg': return {'pixels':int(rng.integers(260,421)), 'quality':int(rng.integers(25,76))}
    if case == 'perspective': return {'pixels':420, 'offsets':rng.uniform(4,32,(4,2)).round(2).tolist()}
    if case == 'noise': return {'pixels':280, 'sigma':round(float(rng.uniform(8,40)),2)}
    raise ValueError('Unknown transform')


def transform(img, case, params, seed):
    img = img.convert('RGB')
    if case == 'original': return img.copy()
    if case == 'blur': return img.filter(ImageFilter.GaussianBlur(params['radius']))
    if 'pixels' in params:
        img = img.resize((params['pixels'],)*2, Image.Resampling.LANCZOS)
    if case == 'jpeg':
        buf=io.BytesIO(); img.save(buf,'JPEG',quality=params['quality']); buf.seek(0)
        return Image.open(buf).convert('RGB')
    if case == 'perspective':
        n=params['pixels']; d=np.array(params['offsets'],np.float32)
        src=np.array([[0,0],[n-1,0],[n-1,n-1],[0,n-1]],np.float32)
        dst=src + d*np.array([[1,1],[-1,1],[-1,-1],[1,-1]],np.float32)
        return Image.fromarray(cv2.warpPerspective(np.asarray(img),cv2.getPerspectiveTransform(src,dst),(n,n),borderValue=(255,255,255)))
    if case == 'noise':
        noise=np.random.default_rng(seed).normal(0,params['sigma'],np.asarray(img).shape)
        return Image.fromarray(np.clip(np.asarray(img).astype(float)+noise,0,255).astype(np.uint8))
    return img


def check_images(plain, double, public, hidden, key, repetitions):
    row={}
    for name, img in (('plain',plain),('double',double)):
        for decoder, fn in (('opencv',decode),('zxing',decode_zxing)):
            start=time.perf_counter()
            try: value=fn(img); ok=value==public; error=None
            except Exception as exc: ok=False; error=type(exc).__name__
            row[name+'_'+decoder]=bool(ok)
            row[name+'_'+decoder+'_ms']=round((time.perf_counter()-start)*1000,2)
            if error: row[name+'_'+decoder+'_error']=error
    start=time.perf_counter()
    try: row['hidden']=read(double,key,repetitions)==(public,hidden)
    except (ValueError, cv2.error): row['hidden']=False
    row['hidden_ms']=round((time.perf_counter()-start)*1000,2)
    return row


def benchmark(public, hidden, key, repetitions=1, trials=3, seed=20261010, progress=lambda *a:None):
    plain, double, budget=build(public,hidden,key,repetitions)
    a,b=make_image(plain),make_image(double)
    rows=[]; total=len(CASES)*trials
    for case in CASES:
        for i in range(trials):
            runseed=seed+CASES.index(case)*10000+i
            params=parameters(case,runseed)
            result=check_images(transform(a,case,params,runseed),transform(b,case,params,runseed),public,hidden,key,repetitions)
            rows.append(dict(case=case, label=LABELS[case], trial=i+1, seed=runseed, parameters=params, **result))
            progress(len(rows),total)
    metrics=('plain_opencv','double_opencv','plain_zxing','double_zxing','hidden')
    summary={case:{m:rate(r[m] for r in rows if r['case']==case) for m in metrics} for case in CASES}
    report=metadata('read_success',seed)
    report.update(public=public, hidden_bytes=len(hidden.encode()), repetitions=repetitions, budget=budget, rows=rows, summary=summary,
                  notes=['同じ試行番号では通常QRと二重QRに同じ変形・ノイズを適用。',
                         '元PNGの反復は同一画像の再試行です。独立標本ではありません。',
                         '95%区間はWilson参考値。固定画像・人工的な条件集合から実機成功率を推定できません。',
                         '裏の成功は表の自動復号からHMAC検証と元メッセージ一致までを含みます。'])
    return report


def capacity(public, key, repetitions=1, max_bytes=32, samples=2, seed=20261010, progress=lambda *a:None):
    upper=min(255,len(DATA_SLOTS)//(8*repetitions)-9)
    limit=min(max_bytes,upper)
    rows=[]
    for length in range(1,limit+1):
        for sample in range(samples):
            rng=np.random.default_rng(seed+length*100+sample)
            hidden=''.join(rng.choice(list('abcdefghijklmnopqrstuvwxyz0123456789'),length))
            a,b,budget=build(public,hidden,key,repetitions)
            row=dict(bytes=length,sample=sample+1,budget_ok=budget['budget_ok'],min_remaining=budget['min_remaining'],changed_modules=budget['changed_modules'],tested=False)
            if budget['budget_ok']:
                pa,pb=make_image(a),make_image(b)
                tests=[]
                for case in ('original','resize','perspective'):
                    runseed=seed+sample+length*100+CASES.index(case)*10000
                    params=parameters(case,runseed)
                    tests.append(dict(case=case,seed=runseed,parameters=params,**check_images(transform(pa,case,params,runseed),transform(pb,case,params,runseed),public,hidden,key,repetitions)))
                row.update(tested=True,tests=tests,
                           clean_pass=all(tests[0][m] for m in ('double_opencv','double_zxing','hidden')),
                           all_conditions_pass=all(t[m] for t in tests for m in ('double_opencv','double_zxing','hidden')))
            rows.append(row)
            progress(len(rows),limit*samples)
    clean=[n for n in range(1,limit+1) if all(r['budget_ok'] and r.get('clean_pass',False) for r in rows if r['bytes']==n)]
    stressed=[n for n in range(1,limit+1) if all(r['budget_ok'] and r.get('all_conditions_pass',False) for r in rows if r['bytes']==n)]
    report=metadata('capacity',seed)
    report.update(public=public,repetitions=repetitions,format_upper_bytes=255,slot_upper_bytes=upper,scanned_through_bytes=limit,
                  full_format_scan=limit==upper,samples_per_length=samples,rows=rows,
                  max_observed_clean_bytes=max(clean,default=0),max_observed_all_conditions_bytes=max(stressed,default=0),
                  notes=['容量はUTF-8バイト数。全長を1バイトずつ走査し、単調性は仮定しません。',
                         '生成する本文は固定seed由来のASCII。同じバイト数でも本文・表・鍵で結果が変わります。',
                         '予算外は画像読み取り未測定として記録。予算内のみ元PNG・縮小・遠近変形を測定。',
                         '最大実測値は今回の標本の最大成功長であり、任意本文の保証容量や実機容量ではありません。'])
    return report


FEATURES=('black_ratio','horizontal_transition','vertical_transition','uniform_2x2')

def features(modules):
    a=np.asarray(modules,bool)
    return np.array([a.mean(),(a[:,1:]!=a[:,:-1]).mean(),(a[1:]!=a[:-1]).mean(),
                     ((a[:-1,:-1]==a[1:,:-1])&(a[:-1,:-1]==a[:-1,1:])&(a[:-1,:-1]==a[1:,1:])).mean()])


def auc(positive,negative):
    diff=np.asarray(positive)[:,None]-np.asarray(negative)[None,:]
    return float((np.sum(diff>0)+0.5*np.sum(diff==0))/diff.size)


def statistics(public, hidden, key, repetitions=1, count=24, seed=20261010, progress=lambda *a:None):
    """Public strings disjoint between training and held-out testing."""
    data=[]; residual=[]; budgets=[]
    for split in ('train','test'):
        for i in range(count):
            suffix=hashlib.sha256(f'{seed}:{split}:{i}'.encode()).hexdigest()[:12]
            value='https://example.com/'+suffix
            a,b,budget=build(value,hidden,key,repetitions)
            data.append((split,features(a.modules),features(b.modules)))
            residual.append((split,0,budget['changed_modules']))
            budgets.append(budget['budget_ok'])
            progress(len(data),2*count)
    train=np.array([v for s,a,b in data if s=='train' for v in (a,b)])
    labels=np.tile([0,1],count)
    scale=np.maximum(train.std(axis=0),1e-6)
    mean=train.mean(axis=0)
    x=(train-mean)/scale
    c0=x[labels==0].mean(axis=0);c1=x[labels==1].mean(axis=0)
    def scores(values):
        x=(values-mean)/scale
        return ((x-c0)**2).sum(axis=1)-((x-c1)**2).sum(axis=1)
    neg=np.array([a for s,a,b in data if s=='test']);pos=np.array([b for s,a,b in data if s=='test'])
    ns,ps=scores(neg),scores(pos)
    a,b,budget=build(public,hidden,key,repetitions)
    report=metadata('statistical_detection',seed)
    report.update(repetitions=repetitions,hidden_bytes=len(hidden.encode()), train_pairs=count,test_pairs=count,
                  features=list(FEATURES), classifier='訓練データで標準化した最近傍クラス重心。閾値0をテスト前に固定。',
                  global_features=dict(auc=round(auc(ps,ns),4),true_positive=rate(ps>0),false_positive=rate(ns>0),
                                       balanced_accuracy=round(float(((ps>0).mean()+(ns<=0).mean())/2),4)),
                  known_encoder_residual=dict(threshold_changed_modules=1,
                       true_positive=rate(b>0 for s,a,b in residual if s=='test'),false_positive=rate(a>0 for s,a,b in residual if s=='test')),
                  current=dict(plain=dict(zip(FEATURES,features(a.modules).tolist())),double=dict(zip(FEATURES,features(b.modules).tolist())),changed_modules=budget['changed_modules']),
                  corpus_budget_pass=sum(budgets), corpus_total=len(budgets),
                  rows=[dict(split=s,plain=a.tolist(),double=b.tolist(),changed_modules=residual[i][2],budget_ok=budgets[i]) for i,(s,a,b) in enumerate(data)],
                  notes=['実測は生成行列の統計値と分類結果。画像スキャンではありません。',
                         '固定V12/H/マスク0・同じ生成器の合成コーパスです。訓練と評価の表URLは分離。',
                         '単純な統計分類器の低AUCは検出耐性の証明ではありません。',
                         '既知生成器差分は表の内容と生成規則を知る観察者が正常QRを再生成する評価。秘密鍵は不要。',
                         '既知生成器差分では通常QRとの差を検出しやすい構造です。撮影ノイズや他生成器の誤検出率は未測定。',
                         '採用可否による選別をせず全生成標本を評価。予算内の標本数も併記。'])
    return report
