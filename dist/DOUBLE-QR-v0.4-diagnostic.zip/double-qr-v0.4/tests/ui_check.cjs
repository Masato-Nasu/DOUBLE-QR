// Run from the application folder after installing Playwright.
let server;const fs=require('fs');const {chromium:pw}=require('playwright');
(async()=>{
server=require('child_process').spawn('.venv/bin/python',['app.py','--port','8766'],{stdio:'ignore'});
for(let i=0;i<50;i++){try{if((await fetch('http://127.0.0.1:8766')).ok)break;}catch{}await new Promise(r=>setTimeout(r,100));}

const b=await pw.launch({headless:true,...(process.env.DOUBLE_QR_CHROMIUM?{executablePath:process.env.DOUBLE_QR_CHROMIUM}:{}),args:["--no-sandbox","--disable-gpu","--no-zygote"]});
const errors=[];const context=await b.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true,deviceScaleFactor:1});const page=await context.newPage();page.on('pageerror',e=>errors.push(e.message));
await page.goto('http://127.0.0.1:8766');
await page.getByRole('button',{name:'二重QRを生成・検査'}).click();await page.waitForFunction(()=>document.getElementById('made').textContent.includes('保存可'));
await page.evaluate(()=>window.scrollTo(0,0));await page.screenshot({path:'reports/mobile-screen.png',fullPage:true});await page.screenshot({path:'reports/mobile-top.png',fullPage:false});
if(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth))throw Error('Mobile horizontal overflow');
await page.getByRole('button',{name:'差分',exact:true}).click();if(!await page.locator('#diffLegend').isVisible())throw Error('Diff missing');
await page.getByRole('button',{name:'二重QR',exact:true}).click();
const data=await page.locator('#qr').getAttribute('src');const buffer=Buffer.from(data.split(',')[1],'base64');
await page.locator('#image').setInputFiles({name:'double.png',mimeType:'image/png',buffer});await page.locator('#readKey').fill('demo-key');await page.getByRole('button',{name:'裏を復元',exact:true}).click();await page.waitForFunction(()=>document.getElementById('result').textContent.includes('裏：SECRET'));
await page.getByRole('button',{name:'表だけ検査'}).click();await page.waitForFunction(()=>document.getElementById('result').textContent.includes('ZXing：https://example.com'));
await page.locator('#trials').fill('1');await page.getByRole('button',{name:'成功率を測定'}).click();await page.waitForFunction(()=>document.getElementById('jobStatus').textContent.includes('完了'),{},{timeout:120000});
const jsonURL=await page.locator('#jsonLink').getAttribute('href');const report=await (await context.request.get('http://127.0.0.1:8766'+jsonURL)).json();if(report.rows.length!==6)throw Error('Missing report rows');
const csvURL=await page.locator('#csvLink').getAttribute('href');const csv=await context.request.get('http://127.0.0.1:8766'+csvURL);if(csv.status()!==200)throw Error('CSV download failed');
await page.locator('#maxBytes').fill('2');await page.locator('#samples').fill('1');await page.getByRole('button',{name:'容量を検証'}).click();await page.waitForFunction(()=>document.getElementById('jobStatus').textContent.includes('完了'),{},{timeout:120000});
await page.locator('#count').fill('8');await page.getByRole('button',{name:'検出を評価'}).click();await page.waitForFunction(()=>document.getElementById('jobStatus').textContent.includes('完了'),{},{timeout:120000});
await page.locator('#device').fill('UI automation (not real phone)');await page.locator('#conditions').fill('390px viewport');await page.getByRole('button',{name:'1試行を記録'}).click();if(!(await page.locator('#phoneSummary').textContent()).includes('1/1'))throw Error('Device record missing');await page.reload();if(!(await page.locator('#phoneSummary').textContent()).includes('1/1'))throw Error('Device record not persisted');await page.getByRole('button',{name:'最後の記録を取り消す'}).click();
await page.locator('#hidden').fill('x'.repeat(100));await page.getByRole('button',{name:'二重QRを生成・検査'}).click();await page.waitForFunction(()=>document.getElementById('made').textContent.includes('検査不合格'));if(await page.locator('#save').isVisible())throw Error('Rejected QR is downloadable');
await page.locator('#hidden').fill('SECRET');await page.locator('#repetitions').selectOption('3');await page.getByRole('button',{name:'二重QRを生成・検査'}).click();await page.waitForFunction(()=>document.getElementById('made').textContent.includes('保存可'));
await page.getByRole('button',{name:'普通のQRを生成'}).click();await page.waitForFunction(()=>document.getElementById('made').textContent.includes('隠しデータはありません'));if(!await page.locator('#save').isVisible())throw Error('Plain save missing');
await page.setViewportSize({width:1440,height:1000});await page.locator('#repetitions').selectOption('1');await page.getByRole('button',{name:'二重QRを生成・検査'}).click();await page.waitForFunction(()=>document.getElementById('made').textContent.includes('保存可'));await page.evaluate(()=>window.scrollTo(0,0));await page.screenshot({path:'reports/desktop-screen.png',fullPage:true});
fs.writeFileSync('reports/ui-tests.json',JSON.stringify({status:'passed',browser:await b.version(),viewport_mobile:[390,844],viewport_desktop:[1440,1000],real_smartphone:false,checks:['generate','plain','diff','PNG','hidden read','front check','benchmark job','capacity job','statistics job','JSON export','CSV export','manual records persist and undo','reject unsafe export','3x profile','mobile no overflow'],errors},null,2));
await b.close();server.kill();if(errors.length)throw Error(errors.join('\n'));console.log('UI tests passed');
})().catch(e=>{if(server)server.kill();console.error(e);process.exit(1)});
