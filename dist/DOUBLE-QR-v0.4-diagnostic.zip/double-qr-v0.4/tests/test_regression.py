import io
import numpy as np
import pytest
import qrcode.util
from PIL import Image
import engine as e
import legacy_v03 as old
from app import app
from experiments import transform, parameters, rate, statistics

PUBLIC='https://example.com'
KEY='demo-key'

@pytest.mark.parametrize('public,hidden,key',[(PUBLIC,'SECRET',KEY),('HELLO','abcdefgh','test-key'),(PUBLIC,'秘密','日本語鍵')])
def test_v03_pixel_and_read_compatibility(public,hidden,key):
    a,_,changed=old.generate(public,hidden,key)
    b,_,changes=e.generate(public,hidden,key)
    assert np.array_equal(a,b)
    assert changed==changes
    assert e.read(a,key)==(public,hidden)
    assert old.read(b,key)==(public,hidden)

@pytest.mark.parametrize('rep',[1,3,5])
def test_default_front_both_decoders_and_hidden(rep):
    a,b,budget,checks=e.verified(PUBLIC,'SECRET',KEY,rep)
    assert all(checks.values())
    assert budget['budget_ok']
    assert len(e.embedding_positions(PUBLIC,KEY,rep))==len(set(e.DATA_SLOTS))
    assert set(e.embedding_positions(PUBLIC,KEY,rep))==set(e.DATA_SLOTS)
    functions=set(np.ndindex(e.N,e.N))-set(e.DATA_SLOTS)
    assert all(a.modules[r][c]==b.modules[r][c] for r,c in functions)


def test_codeword_coordinates_against_qrcode_map_data():
    mapping,blocks=e.codeword_map()
    assert len(mapping)==sum(b.total_count for b in blocks)*8
    rng=np.random.default_rng(4321)
    data=rng.integers(0,256,sum(b.total_count for b in blocks)).tolist()
    q=e.base_qr(PUBLIC)
    for r,c in e.DATA_SLOTS:q.modules[r][c]=None
    q.map_data(data,e.MASK)
    mask=qrcode.util.mask_func(e.MASK)
    # independently determine bit membership by illuminating one bit plane
    for bit in range(8):
        q2=e.base_qr(PUBLIC)
        for r,c in e.DATA_SLOTS:q2.modules[r][c]=None
        q2.map_data([1<<(7-bit)]*len(data),e.MASK)
        for rc,(cw,block) in mapping.items():
            r,c=rc
            if bool(q2.modules[r][c]) ^ bool(mask(r,c)):
                assert bool(q.modules[r][c]) ^ bool(mask(r,c)) == bool((data[cw]>>(7-bit))&1)
    counts=np.bincount([b for _,b in mapping.values()])//8
    assert counts.tolist()==[b.total_count for b in blocks]


@pytest.mark.parametrize('rep',[3,5])
def test_majority_recovers_corrupted_header_and_body(rep):
    _,q,_=e.build(PUBLIC,'SECRET',KEY,rep)
    grid=np.array(q.modules,bool)
    loc=e.embedding_positions(PUBLIC,KEY,rep)
    # One of repeated copies has header and payload errors.
    for i in (0,1,8,15,38):
        r,c=loc[i];grid[r,c]=not grid[r,c]
    assert e.read_grid(PUBLIC,grid,KEY,rep)==(PUBLIC,'SECRET')


def test_wrong_key_wrong_strength_and_tampering_rejected():
    _,q,_=e.build(PUBLIC,'SECRET',KEY)
    img=e.make_image(q)
    with pytest.raises(ValueError):e.read(img,'wrong-key')
    with pytest.raises(ValueError):e.read(img,KEY,3)
    grid=np.array(q.modules,bool);r,c=e.embedding_positions(PUBLIC,KEY)[20];grid[r,c]=not grid[r,c]
    with pytest.raises(ValueError):e.read_grid(PUBLIC,grid,KEY)


@pytest.mark.parametrize('rep',[1,3,5])
def test_original_and_rotated_image_decode(rep):
    _,q,_=e.build(PUBLIC,'SECRET',KEY,rep)
    image=e.make_image(q).rotate(90,expand=True)
    assert e.read(image,KEY,rep)==(PUBLIC,'SECRET')


def test_input_limits_and_utf8():
    with pytest.raises(ValueError):e.build(PUBLIC,'',KEY)
    with pytest.raises(ValueError):e.build(PUBLIC,'a'*256,KEY)
    with pytest.raises(ValueError):e.build(PUBLIC,'a',KEY,2)
    _,q,_=e.build(PUBLIC,'秘密の文',KEY,3)
    assert e.read(e.make_image(q),KEY,3)==(PUBLIC,'秘密の文')


def test_api_preserves_routes_and_rejects_bad_candidates():
    client=app.test_client();data=dict(public=PUBLIC,hidden='SECRET',key=KEY)
    plain=client.post('/plain',data=data);made=client.post('/make',data=data)
    assert plain.status_code==made.status_code==200
    assert Image.open(io.BytesIO(made.data)).size==(1078,1078)
    result=client.post('/read',data=dict(image=(io.BytesIO(made.data),'a.png'),key=KEY)).json
    assert result==dict(public=PUBLIC,hidden='SECRET')
    assert client.post('/check',data=dict(image=(io.BytesIO(plain.data),'a.png'))).json['public']==PUBLIC
    details=client.post('/api/analyze',data=data).json
    assert details['accepted'] and set(details['images'])=={'plain','double','diff'}
    rejected=client.post('/make',data={**data,'hidden':'x'*100})
    assert rejected.status_code==422
    assert client.post('/read',data=dict(image=(io.BytesIO(b'invalid'),'a.png'),key=KEY)).status_code==400
    assert client.post('/plain',data=data,headers={'Origin':'https://example.net'}).status_code==403
    assert client.get('/').status_code==200


def test_transform_pairing_and_statistics():
    p=e.make_image(e.base_qr(PUBLIC));params=parameters('noise',123)
    assert np.array_equal(transform(p,'noise',params,123),transform(p,'noise',params,123))
    r=rate([True,False]);assert r['success']==1 and r['trials']==2
    assert r['wilson95_percent'][0]<50<r['wilson95_percent'][1]
    report=statistics(PUBLIC,'SECRET',KEY,count=8)
    assert report['known_encoder_residual']['false_positive']['success']==0
    assert report['known_encoder_residual']['true_positive']['success']==8
    assert len(report['rows'])==16

@pytest.mark.parametrize('case',['blur','jpeg','perspective'])
def test_independent_geometry_fallback(case):
    from experiments import CASES
    _,q,_=e.build(PUBLIC,'SECRET',KEY)
    seed=20261010+CASES.index(case)*10000
    image=transform(e.make_image(q),case,parameters(case,seed),seed)
    assert e.read(image,KEY)==(PUBLIC,'SECRET')
