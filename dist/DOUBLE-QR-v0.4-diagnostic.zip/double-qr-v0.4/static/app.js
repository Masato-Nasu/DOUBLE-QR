'use strict';
const $=id=>document.getElementById(id);
let generated=null, view='double', busy=false;
const names={plain:'通常QR',double:'二重QR',diff:'白黒パターンの差分'};
const byteLength=s=>new TextEncoder().encode(s).length;
function updateBytes(){$('byteCount').textContent=`${byteLength($('hidden').value)} bytes`;}
$('hidden').addEventListener('input',updateBytes);updateBytes();
async function responseJSON(response){const body=await response.json();if(!response.ok)throw Error(body.error||'処理に失敗しました');return body;}
function showImage(next){
 view=next;if(!generated)return;
 $('comparison').hidden=false;$('qr').src=generated.images[next];$('qr').alt=names[next];
 $('imageCaption').textContent=names[next]+(next==='double'&&!generated.accepted?' · 診断用（検査不合格）':'');
 $('diffLegend').hidden=next!=='diff';
 document.querySelectorAll('[data-view]').forEach(b=>{b.classList.toggle('selected',b.dataset.view===next);b.disabled=!generated.images[b.dataset.view];});
 $('save').hidden=next==='double'&&!generated.accepted;
 $('save').href=generated.images[next];$('save').download={plain:'ordinary-qr.png',double:'double-qr.png',diff:'double-qr-difference.png'}[next];
}
document.querySelectorAll('[data-view]').forEach(b=>b.onclick=()=>showImage(b.dataset.view));
function renderDiagnostics(data){
 $('diagnostics').hidden=false;$('checks').replaceChildren();
 for(const [label,ok] of [['表 · OpenCV',data.checks.opencv],['表 · ZXing',data.checks.zxing],['裏 · 本文一致',data.checks.hidden]]){
  const card=document.createElement('div');card.className='card';card.textContent=label;
  const result=document.createElement('strong');result.className=ok?'good':'bad';result.textContent=ok?'成功':'失敗';card.append(result);$('checks').append(card);
 }
 $('budgetText').textContent=`実測：${data.budget.total_modules}マス中 ${data.budget.changed_modules}マス変更（${data.budget.changed_percent}%）。計算値：最も少ない訂正残量 ${data.budget.min_remaining}語。保存条件は各ブロック2語以上。`;
 $('blocks').replaceChildren();
 for(const b of data.budget.blocks){const tr=document.createElement('tr');for(const v of [b.block,b.changed_codewords,b.correction_limit,b.remaining]){const td=document.createElement('td');td.textContent=v;tr.append(td);}$('blocks').append(tr);}
}
$('maker').onsubmit=async e=>{
 e.preventDefault();const button=e.submitter;button.disabled=true;$('made').textContent='表・裏・訂正余裕を検査中…';$('comparison').hidden=true;$('diagnostics').hidden=true;
 try{generated=await responseJSON(await fetch('/api/analyze',{method:'POST',body:new FormData(e.target)}));$('made').textContent=generated.status;showImage('double');renderDiagnostics(generated);}
 catch(err){generated=null;$('made').textContent=err.message;}finally{button.disabled=false;}
};
let plainURL;
$('plainBtn').onclick=async()=>{
 $('plainBtn').disabled=true;$('made').textContent='通常QRを生成中…';$('comparison').hidden=true;$('diagnostics').hidden=true;
 try{const response=await fetch('/plain',{method:'POST',body:new FormData($('maker'))});if(!response.ok)await responseJSON(response);if(plainURL)URL.revokeObjectURL(plainURL);plainURL=URL.createObjectURL(await response.blob());generated={images:{plain:plainURL},accepted:false};showImage('plain');$('made').textContent='通常QRです。隠しデータはありません。';}
 catch(err){generated=null;$('made').textContent=err.message;}finally{$('plainBtn').disabled=false;}
};
$('fullscreen').onclick=async()=>{const wrap=document.querySelector('.qr-wrap');try{if(wrap.requestFullscreen)await wrap.requestFullscreen();else window.open($('qr').src,'_blank','noopener');}catch(err){$('made').textContent='このブラウザでは全画面表示に対応していません。画像を保存して拡大してください。';}};
async function readImage(frontOnly){
 if(!$('image').files.length){$('result').textContent='画像を選択してください。';return;}
 const buttons=$('reader').querySelectorAll('button');buttons.forEach(b=>b.disabled=true);$('result').textContent='解析中…';
 try{const data=await responseJSON(await fetch(frontOnly?'/check':'/read',{method:'POST',body:new FormData($('reader'))}));$('result').textContent=frontOnly?`表 · OpenCV：${data.public}\n表 · ZXing：${data.zxing||'読み取り失敗'}`:`表：${data.public}\n裏：${data.hidden}`;}
 catch(err){$('result').textContent=err.message;}finally{buttons.forEach(b=>b.disabled=false);}
}
$('reader').onsubmit=e=>{e.preventDefault();readImage(false);};$('checkBtn').onclick=()=>readImage(true);
function table(headers,rows){const wrap=document.createElement('div');wrap.className='table-scroll';const t=document.createElement('table');const head=document.createElement('thead');const tr=document.createElement('tr');headers.forEach(h=>{const th=document.createElement('th');th.textContent=h;tr.append(th);});head.append(tr);t.append(head);const body=document.createElement('tbody');rows.forEach(row=>{const tr=document.createElement('tr');row.forEach(v=>{const td=document.createElement('td');td.textContent=v;tr.append(td);});body.append(tr);});t.append(body);wrap.append(t);return wrap;}
function rateText(r){return r.trials?`${r.success}/${r.trials} · ${r.percent}%`:'未測定';}
function paragraph(container,text){const p=document.createElement('p');p.textContent=text;container.append(p);}
function renderReport(r){
 const out=$('report');out.replaceChildren();paragraph(out,r.evidence);
 if(r.kind==='read_success'){
 const labels={original:'元PNG',resize:'縮小',blur:'ぼかし',jpeg:'JPEG',perspective:'遠近変形',noise:'ノイズ'};
 out.append(table(['条件','通常 · CV','二重 · CV','通常 · ZXing','二重 · ZXing','裏復元'],Object.entries(r.summary).map(([c,m])=>[labels[c],...['plain_opencv','double_opencv','plain_zxing','double_zxing','hidden'].map(k=>rateText(m[k]))])));
 paragraph(out,'95% Wilson参考区間と全試行の条件・処理時間はJSONに含まれます。');
 }else if(r.kind==='capacity'){
 paragraph(out,`今回の最大成功長：元PNG ${r.max_observed_clean_bytes} bytes / 全測定条件 ${r.max_observed_all_conditions_bytes} bytes。実機の保証容量ではありません。`);
 paragraph(out,`形式上限 ${r.format_upper_bytes} bytes、マス数による上限 ${r.slot_upper_bytes} bytes。今回の走査は1〜${r.scanned_through_bytes} bytes（${r.full_format_scan?'形式範囲を全走査':'上限までの全走査ではありません'}）。各長さ${r.samples_per_length}本文。`);
 const lengths=[...new Set(r.rows.map(x=>x.bytes))];
 out.append(table(['長さ','予算内の本文','元PNG合格','全条件合格'],lengths.map(n=>{const rows=r.rows.filter(x=>x.bytes===n);return[n+' B',`${rows.filter(x=>x.budget_ok).length}/${rows.length}`,`${rows.filter(x=>x.clean_pass).length}/${rows.length}`,`${rows.filter(x=>x.all_conditions_pass).length}/${rows.length}`];})));
 paragraph(out,'予算外の本文は読み取り未測定です。合格数の分母は生成した本文の総数です。');
 }else{
 paragraph(out,`統計分類のAUC：${r.global_features.auc}（0.5付近はこの分類器で区別しにくいという意味です）。訓練${r.train_pairs}ペア / 別URLの評価${r.test_pairs}ペア。`);
 out.append(table(['検出手法','二重QRを検出','通常QRの誤検出'],[['白黒統計の分類',rateText(r.global_features.true_positive),rateText(r.global_features.false_positive)],['既知生成器とのマス差分',rateText(r.known_encoder_residual.true_positive),rateText(r.known_encoder_residual.false_positive)]]));
 paragraph(out,`評価コーパスの訂正予算内：${r.corpus_budget_pass}/${r.corpus_total}ペア。`);
 out.append(table(['現在の画像の統計値','通常QR','二重QR'],r.features.map(k=>[k,r.current.plain[k].toFixed(5),r.current.double[k].toFixed(5)])));
 }
 r.notes.forEach(n=>paragraph(out,n));
}
document.querySelectorAll('[data-job]').forEach(b=>b.onclick=async()=>{
 if(busy)return;if(!$('maker').reportValidity())return;busy=true;
 document.querySelectorAll('[data-job]').forEach(el=>el.disabled=true);$('downloads').hidden=true;$('report').replaceChildren();$('jobStatus').textContent='測定を開始しています…';$('progress').hidden=false;$('progress').removeAttribute('value');
 try{
 const body=Object.fromEntries(new FormData($('maker')));Object.assign(body,{kind:b.dataset.job,trials:+$('trials').value,max_bytes:+$('maxBytes').value,samples:+$('samples').value,count:+$('count').value,seed:+$('seed').value});
 const start=await responseJSON(await fetch('/api/jobs',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}));
 while(true){
  const job=await responseJSON(await fetch(`/api/jobs/${start.id}`));
  $('jobStatus').textContent=`自動測定中：${job.done} / ${job.total||'準備中'}。この画面でお待ちください。`;
  if(job.total){$('progress').max=job.total;$('progress').value=job.done;}
  if(job.status==='error')throw Error(job.error);
  if(job.status==='complete'){renderReport(job.report);$('jobStatus').textContent='自動測定が完了しました。スマートフォン実機の測定結果ではありません。';$('downloads').hidden=false;$('jsonLink').href=`/api/jobs/${start.id}/download`;$('csvLink').href=`/api/jobs/${start.id}/download?format=csv`;break;}
  await new Promise(resolve=>setTimeout(resolve,700));
 }
 }catch(err){$('jobStatus').textContent=err.message;}finally{busy=false;$('progress').hidden=true;document.querySelectorAll('[data-job]').forEach(el=>el.disabled=false);}
});
const storageKey='double-qr-v04-device-trials';let phoneRows=[];
try{const stored=JSON.parse(localStorage.getItem(storageKey)||'[]');if(Array.isArray(stored))phoneRows=stored;}catch(err){$('phoneStatus').textContent='保存済み記録を読めませんでした。';}
function renderPhone(){const out=$('phoneSummary');out.replaceChildren();if(!phoneRows.length){paragraph(out,'v0.4 実機記録：0件（未測定）');return;}const groups=new Map();for(const r of phoneRows){const key=JSON.stringify([r.device,r.conditions,r.target,r.repetitions,r.hidden_bytes]);if(!groups.has(key))groups.set(key,{row:r,total:0,success:0});const g=groups.get(key);g.total++;g.success+=r.success?1:0;}out.append(table(['端末 / 条件','対象 / 強度 / 容量','成功 / 試行'],[...groups.values()].map(g=>[`${g.row.device} / ${g.row.conditions}`,`${{plain:'通常・表',double:'二重・表',hidden:'二重・裏'}[g.row.target]} / ${g.row.repetitions}重 / ${g.row.hidden_bytes}B`,`${g.success}/${g.total} · ${(g.success/g.total*100).toFixed(1)}%`])));}
function persistPhone(){try{localStorage.setItem(storageKey,JSON.stringify(phoneRows));$('phoneStatus').textContent='このブラウザに保存しました。';}catch(err){$('phoneStatus').textContent='ブラウザへの保存に失敗しました。JSONを保存してください。';}renderPhone();}
$('phoneForm').onsubmit=e=>{e.preventDefault();const target=$('phoneKind').value;phoneRows.push({version:'0.4',evidence:'user_reported_device_test',timestamp:new Date().toISOString(),device:$('device').value,conditions:$('conditions').value,target,repetitions:target==='plain'?0:+$('phoneRep').value,hidden_bytes:target==='plain'?0:+$('phoneBytes').value,success:$('outcome').value==='success'});persistPhone();};
$('undoPhone').onclick=()=>{phoneRows.pop();persistPhone();};
$('exportPhone').onclick=()=>{const blob=new Blob([JSON.stringify({evidence:'スマートフォン実機・ユーザー手動記録',rows:phoneRows},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='double-qr-device-tests.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};renderPhone();
