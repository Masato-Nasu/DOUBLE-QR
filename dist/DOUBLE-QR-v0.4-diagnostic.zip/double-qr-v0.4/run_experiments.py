"""CLI mirrors the UI; save reproducible reports without opening a browser."""
import argparse,json
from pathlib import Path
import experiments
p=argparse.ArgumentParser()
p.add_argument('kind',choices=['benchmark','capacity','statistics'])
p.add_argument('--public',default='https://example.com')
p.add_argument('--hidden',default='SECRET')
p.add_argument('--key',default='demo-key',help='試験専用鍵。秘密鍵をシェル履歴に残さないこと。')
p.add_argument('--repetitions',type=int,choices=[1,3,5],default=1)
p.add_argument('--seed',type=int,default=20261010)
p.add_argument('--trials',type=int,default=3)
p.add_argument('--max-bytes',type=int,default=32)
p.add_argument('--samples',type=int,default=2)
p.add_argument('--count',type=int,default=24)
p.add_argument('--output',default='reports/result.json')
a=p.parse_args()
def progress(done,total):
 if done==total or done%10==0: print(f'{done}/{total}',flush=True)
if a.kind=='benchmark':r=experiments.benchmark(a.public,a.hidden,a.key,a.repetitions,a.trials,a.seed,progress)
elif a.kind=='capacity':r=experiments.capacity(a.public,a.key,a.repetitions,a.max_bytes,a.samples,a.seed,progress)
else:r=experiments.statistics(a.public,a.hidden,a.key,a.repetitions,a.count,a.seed,progress)
path=Path(a.output);path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(r,ensure_ascii=False,indent=2))
print(path)
