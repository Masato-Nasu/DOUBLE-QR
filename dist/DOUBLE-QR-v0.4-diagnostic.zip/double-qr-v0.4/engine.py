"""v0.4: v0.3 wire format and module layout remain the default."""
import base64
import hashlib
import hmac
import io
from functools import lru_cache
import cv2
import numpy as np
import qrcode.base
import zxingcpp
from PIL import Image
from legacy_v03 import (VERSION, MASK, DATA_SLOTS, base_qr, positions,
                        keystream, bits_from_bytes, make_image, decode)

MAX_SECRET_BYTES = 255  # length-field limit, NOT a reliably usable capacity
REPETITIONS = (1, 3, 5)
N = VERSION * 4 + 17


def decode_zxing(img):
    results = zxingcpp.read_barcodes(np.asarray(img.convert('RGB')), formats=zxingcpp.BarcodeFormat.QRCode)
    return results[0].text if results else ''


def payload(public, hidden, key):
    body = hidden.encode('utf-8')
    if not 1 <= len(body) <= MAX_SECRET_BYTES:
        raise ValueError('裏メッセージはUTF-8で1〜255バイトです。実際に使える容量はこれより小さくなります。')
    stream, mac_key = keystream(public, key, len(body))
    enc = bytes(a ^ b for a, b in zip(body, stream))
    return bytes([len(body)]) + enc + hmac.digest(mac_key, b'tag' + public.encode() + bytes([len(body)]) + enc, 'sha256')[:8]


@lru_cache(maxsize=1)
def codeword_map():
    """QR zig-zag bit placement -> interleaved codeword -> RS block."""
    available = set(DATA_SLOTS)
    ordered = []
    row, direction = N - 1, -1
    for col0 in range(N - 1, 0, -2):
        col = col0 - 1 if col0 <= 6 else col0
        while True:
            for c in (col, col - 1):
                if (row, c) in available:
                    ordered.append((row, c))
            row += direction
            if row < 0 or row >= N:
                row -= direction
                direction = -direction
                break
    blocks = qrcode.base.rs_blocks(VERSION, qrcode.constants.ERROR_CORRECT_H)
    interleaved = []
    for i in range(max(b.data_count for b in blocks)):
        interleaved.extend(j for j, b in enumerate(blocks) if i < b.data_count)
    for i in range(max(b.total_count - b.data_count for b in blocks)):
        interleaved.extend(j for j, b in enumerate(blocks) if i < b.total_count - b.data_count)
    mapping = {rc: (i // 8, interleaved[i // 8]) for i, rc in enumerate(ordered) if i // 8 < len(interleaved)}
    return mapping, blocks


def rs_metrics(base, modified, reserve=2):
    mapping, blocks = codeword_map()
    changed = np.asarray(base, dtype=bool) != np.asarray(modified, dtype=bool)
    affected = [set() for _ in blocks]
    for r, c in np.argwhere(changed):
        if (int(r), int(c)) in mapping:
            cw, block = mapping[(int(r), int(c))]
            affected[block].add(cw)
    rows = []
    for i, b in enumerate(blocks):
        t = (b.total_count - b.data_count) // 2
        errors = len(affected[i])
        rows.append(dict(block=i + 1, changed_codewords=errors, correction_limit=t,
                         remaining=t-errors, reserve=reserve))
    return dict(changed_modules=int(changed.sum()), total_modules=N*N,
                changed_percent=round(100 * changed.mean(), 3), blocks=rows,
                min_remaining=min(x['remaining'] for x in rows),
                budget_ok=all(x['remaining'] >= reserve for x in rows),
                reserve=reserve,
                interpretation='計算値：各RSブロックの訂正限界と変更コードワード数。撮影時の成功率を保証しません。')


def embedding_positions(public, key, repetitions=1):
    original = positions(public, key, len(DATA_SLOTS))
    if repetitions == 1:
        return original
    # v0.4 redundant profiles group bits into codewords, distributing words
    # round-robin across RS blocks to avoid exhausting one block early.
    mapping, blocks = codeword_map()
    groups = {}
    per_block = [[] for _ in blocks]
    remainder = []
    for rc in original:
        if rc not in mapping:
            remainder.append(rc)
            continue
        cw, block = mapping[rc]
        if cw not in groups:
            groups[cw] = []
            per_block[block].append(cw)
        groups[cw].append(rc)
    ordered = []
    for index in range(max(map(len, per_block))):
        for words in per_block:
            if index < len(words):
                ordered.extend(groups[words[index]])
    return ordered + remainder


def build(public, hidden, key, repetitions=1):
    if not public.strip() or not key:
        raise ValueError('表の内容と秘密鍵を入力してください。')
    if repetitions not in REPETITIONS:
        raise ValueError('繰り返し数は1、3、5から選択してください。')
    plain = base_qr(public)
    modified = base_qr(public)
    bits = bits_from_bytes(payload(public, hidden, key))
    # Each repetition uses one contiguous packet; 1x is byte-for-byte v0.3.
    loc = embedding_positions(public, key, repetitions)
    if len(bits) * repetitions > len(loc):
        raise ValueError('この強度では埋め込み用のマスが不足します。')
    for (r, c), bit in zip(loc, bits * repetitions):
        modified.modules[r][c] = bool(bit)
    return plain, modified, rs_metrics(plain.modules, modified.modules)


def generate(public, hidden, key, repetitions=1):
    plain, modified, metrics = build(public, hidden, key, repetitions)
    img = make_image(modified)
    return img, decode(img), metrics['changed_modules']


def _warp_grid(img, corners):
    size = N * 10
    dst = np.array([[0, 0], [size, 0], [size, size], [0, size]], np.float32)
    gray = np.asarray(img.convert('L'))
    warp = cv2.warpPerspective(gray, cv2.getPerspectiveTransform(corners, dst), (size+1, size+1))
    threshold, _ = cv2.threshold(warp, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    centers = np.arange(N)*10+5
    patches = warp[centers[:,None,None,None] + np.arange(-1,2)[None,None,:,None],
                   centers[None,:,None,None] + np.arange(-1,2)[None,None,None,:]]
    return np.median(patches, axis=(2,3)) <= threshold


def candidate_grids(img):
    rgb = np.asarray(img.convert('RGB'))
    public, points, _ = cv2.QRCodeDetector().detectAndDecode(cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR))
    if public and points is not None:
        yield public, _warp_grid(img, np.asarray(points[0], np.float32))
    # A decoder may repair the public data despite inaccurate corners. If the
    # hidden tag fails, try independent ZXing geometry, never repaired modules.
    found = zxingcpp.read_barcodes(rgb, formats=zxingcpp.BarcodeFormat.QRCode)
    for result in found[:1]:
        p = result.position
        corners = np.array([(v.x, v.y) for v in (p.top_left, p.top_right, p.bottom_right, p.bottom_left)], np.float32)
        yield result.text, _warp_grid(img, corners)


def sample_grid(img):
    for candidate in candidate_grids(img):
        return candidate
    raise ValueError('標準QRとして読み取れませんでした。')


def _unpack(public, key, raw):
    length = raw[0]
    enc, tag = raw[1:1+length], raw[1+length:9+length]
    stream, mac_key = keystream(public, key, length)
    expected = hmac.digest(mac_key, b'tag'+public.encode()+bytes([length])+enc, 'sha256')[:8]
    if not hmac.compare_digest(tag, expected):
        raise ValueError('裏データがありません。鍵・強度の違い、または画像の破損が考えられます。')
    return bytes(a ^ b for a, b in zip(enc, stream)).decode('utf-8')


def read_grid(public, grid, key, repetitions=1):
    if not key or repetitions not in REPETITIONS:
        raise ValueError('鍵と正しい強度を指定してください。')
    loc = embedding_positions(public, key, repetitions)
    observed = np.array([grid[r, c] for r, c in loc], dtype=np.uint8)
    # At 3x/5x, length header itself can be damaged: bounded candidate search,
    # validate consensus length before doing the expensive key derivation.
    candidates = range(1, min(255, len(loc)//(8*repetitions)-9)+1) if repetitions > 1 else [int(np.packbits(observed[:8])[0])]
    for length in candidates:
        width = (length+9)*8
        if not length or width*repetitions > len(loc):
            continue
        bits = (observed[:width*repetitions].reshape(repetitions, width).sum(axis=0) > repetitions//2).astype(np.uint8)
        raw = np.packbits(bits).tobytes()
        if raw[0] != length:
            continue
        try:
            return public, _unpack(public, key, raw)
        except (ValueError, UnicodeDecodeError):
            continue
    raise ValueError('裏データがありません。鍵・強度の違い、または画像の破損が考えられます。')


def read(img, key, repetitions=1):
    detected = False
    for public, grid in candidate_grids(img):
        detected = True
        try:
            return read_grid(public, grid, key, repetitions)
        except ValueError:
            continue
    if not detected:
        raise ValueError('標準QRとして読み取れませんでした。')
    raise ValueError('裏データがありません。鍵・強度の違い、または画像の破損が考えられます。')


def png_data(img):
    out = io.BytesIO()
    img.save(out, 'PNG')
    return 'data:image/png;base64,' + base64.b64encode(out.getvalue()).decode('ascii')


def difference_image(plain, modified):
    a, b = np.asarray(plain.modules, bool), np.asarray(modified.modules, bool)
    canvas = np.full((N, N, 3), 245, np.uint8)
    canvas[a & b] = [205, 210, 211]
    canvas[~a & b] = [0, 100, 210]  # white -> black
    canvas[a & ~b] = [215, 70, 35]  # black -> white
    return Image.fromarray(np.pad(canvas, ((6,6),(6,6),(0,0)), constant_values=255)).resize(((N+12)*10,)*2, Image.Resampling.NEAREST)


def verified(public, hidden, key, repetitions=1):
    plain, modified, metrics = build(public, hidden, key, repetitions)
    img = make_image(modified)
    checks = dict(opencv=decode(img)==public, zxing=decode_zxing(img)==public, hidden=False)
    try:
        checks['hidden'] = read(img, key, repetitions) == (public, hidden)
    except ValueError:
        pass
    return plain, modified, metrics, checks
