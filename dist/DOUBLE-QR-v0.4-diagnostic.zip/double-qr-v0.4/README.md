# DOUBLE QR v0.4

v0.3診断版を基にしたLinux用のローカルWebアプリです。通常QRと二重QRの生成・PNG保存・表の検査・鍵を使う裏の復元を維持し、差分、成功率、容量、埋め込み強度、統計評価、実機記録を追加しました。

## 起動（Linux Mint）

ZIPをダウンロードしたら、以下をターミナルへまとめて貼り付けてください。ダウンロードフォルダからデスクトップへ展開します。v0.3のフォルダは上書きしません。同名v0.4が既にある場合は日時付きの別フォルダへ展開します。

```bash
python3 - <<'PY'
from pathlib import Path
from datetime import datetime
import subprocess, zipfile
src = Path(subprocess.check_output(['xdg-user-dir', 'DOWNLOAD'], text=True).strip()) / 'DOUBLE-QR-v0.4.zip'
desktop = Path(subprocess.check_output(['xdg-user-dir', 'DESKTOP'], text=True).strip())
if not src.is_file():
    raise SystemExit('DOUBLE-QR-v0.4.zipをダウンロードフォルダに保存してください。')
dest = desktop
if (dest / 'double-qr-v0.4').exists():
    dest = desktop / ('DOUBLE-QR-v0.4-' + datetime.now().strftime('%Y%m%d-%H%M%S'))
dest.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(src) as archive:
    archive.extractall(dest)
folder = dest / 'double-qr-v0.4'
print('起動フォルダ：', folder, flush=True)
subprocess.run(['bash', 'start.sh'], cwd=folder, check=True)
PY
```

初回は必要なPythonライブラリをインターネットから取得します。起動したらブラウザで **http://127.0.0.1:8765** を開いてください。停止はターミナルで **Ctrl+C**。Python 3.10以上を想定し、今回の自動テストはPython 3.12環境で実行しています。実際のLinux Mint端末での実行確認は未実施です。

`venv`がない場合だけ次を実行し、再度起動してください。

```bash
sudo apt update
sudo apt install -y python3-venv
```

通常の展開先から2回目以降に起動するコマンド：

```bash
cd "$(xdg-user-dir DESKTOP)/double-qr-v0.4" && bash start.sh
```

日時付きの別フォルダへ展開された場合は、その中の`double-qr-v0.4`でターミナルを開き、`bash start.sh`を実行してください。

## スマートフォンで操作

PCとスマートフォンを同じWi-Fiにつなぎます。起動中ならCtrl+Cで止めてから：

```bash
cd "$(xdg-user-dir DESKTOP)/double-qr-v0.4" && bash start.sh --lan
```

ターミナルにPCのLANアドレスが表示されます。たとえば `192.168.1.20` ならスマートフォンで `http://192.168.1.20:8765` を開きます。PCは起動したままにします。複数のアドレスが出た場合はPCのWi-Fi接続のIPv4アドレスを使ってください。接続できない場合は同じWi-Fi、ゲスト端末分離、PCのファイアウォールを確認してください。

画像入力はファイル選択を使うため、HTTPでもスマホの画像選択・OS側の撮影が使えます（対応する選択肢は端末依存）。ブラウザ内ライブカメラは実装していません。HEICはJPEG/PNGへ変換してください。LANモードは同じネットワークからアクセス可能です。外部公開用サーバーではありません。

## 最初の確認

1. 表 `https://example.com`、裏 `SECRET`、鍵 `demo-key`、強度「標準・1重」のまま生成。
2. 表のOpenCV検査・ZXing検査・裏本文一致の3項目を確認。
3. PCで「通常QR」を表示し、スマートフォンの標準カメラでURLを確認。
4. 「二重QR」に切り替え、同じ条件でURLを確認。
5. 保存した二重QRを「画像を読み取る」で選び、同じ鍵と強度で `SECRET` の復元を確認。
6. 撮影写真でも試し、その結果は「スマートフォン実機記録」に記録。写真で失敗した場合も失敗として残す。

v0.3でユーザーが確認した標準カメラと専用復元の成功は、v0.4実機測定の件数に流用していません。

## 追加機能

- **差分**：同じ表・V12/H/マスク0の通常QRと比較。青は白→黒、橙は黒→白。変更マス数も表示。
- **成功率**：元PNG・縮小・ぼかし・JPEG・遠近変形・ノイズの6条件。通常と二重に同じ変形パラメータを適用。OpenCV、ZXing、裏本文一致を分けて集計。JSONに全試行、変形パラメータ、処理時間、参考Wilson区間を保存。
- **容量**：1バイトから指定上限まで全長を走査。各長さで固定seed由来のASCII本文を生成。訂正予算内だけを元PNG・縮小・遠近変形で測定。予算外は「読み取り未測定」。2標本なら両方合格した長さの最大値を表示。
- **強度**：標準1重はv0.3と同じ。3重・5重はコードワードごとに配置をまとめ、RSブロック間に配分して多数決で復元。3/5重はv0.4の専用読み取りが必要。1重と3/5重は配置方式も違うため、数値だけで性能を順位付けしない。
- **検出**：白黒統計に基づく簡易分類器と、既知生成器差分による検出を評価。未知の攻撃や写真を対象とした検出率は測定していない。
- **実機記録**：端末、リーダー、条件、強度、裏バイト数ごとに手動記録。ブラウザへ保存、最後の記録の取消、JSON出力。

## 表を守る保存条件

通常の二重QR保存には以下をすべて要求します。

1. OpenCVとZXingの両方で表が元の入力と一致。
2. 専用読み取りで裏が元の入力と一致し、認証タグが正しい。
3. **各RSブロック**の変更コードワード数が、そのブロックの訂正限界より2語以上少ない。

検査に落ちた候補も診断画面と測定では扱えますが、二重QRの通常保存ボタンと`/make`は通しません。診断画像自体を画面撮影することを技術的に禁止するものではありません。マス数が少なくても多数のコードワードへ分散すると訂正余裕を多く消費します。「H=画像の30%を変更してよい」という判定はしていません。

## 値の区別

- **自動実測**：生成した画像をPC上のデコーダーに通した結果、生成行列の統計・分類結果。
- **実機実測（ユーザー記録）**：実際のスマートフォンで行った結果。自動テストと混ぜない。
- **計算値**：1バイト長さ欄の上限255B、マス数による上限、RSの訂正限界と消費量。
- **未確認**：他の本文・鍵・端末への一般化、実機保証容量、撮影・印刷の安定性、未知の検出器への耐性。

成功率の試行は一つの表・裏・鍵を中心とした合成条件です。元PNGは同一画像の反復で独立標本ではありません。Wilson区間は参考値で、実機成功率の信頼区間ではありません。本文や撮影環境を変えた独立した追試が必要です。

## 同梱測定とテスト

- `reports/VALIDATION.md`：今回の結果と限界。
- `reports/benchmark-{1,3,5}x.json`：読み取り成功率の全試行。
- `reports/capacity-{1,3,5}x.json`：各形式のマス数／長さ欄の上限までの容量走査。
- `reports/statistics-{1,3,5}x.json`：訓練・評価別の統計データ。
- `reports/environment-tested.txt`：テスト環境の依存ライブラリ。
- `RESEARCH.md`：既存研究との比較と暗号上の限界。
- `baseline/DOUBLE-QR-prototype-v0.3-diagnostic.zip`：改変していない元ZIP。
- `legacy_v03.py`：元のエンジン。回帰テストの基準。

アプリのフォルダで再テスト：

```bash
.venv/bin/python -m pip install -r requirements-dev.txt
.venv/bin/python -m pytest -q tests
.venv/bin/python run_experiments.py benchmark --repetitions 1 --trials 5 --output reports/my-benchmark.json
.venv/bin/python run_experiments.py capacity --repetitions 3 --max-bytes 255 --samples 2 --output reports/my-capacity.json
.venv/bin/python run_experiments.py statistics --repetitions 1 --count 24 --output reports/my-statistics.json
```

画面からも同じ処理を実行できます。測定は1件ずつ実行し、結果をJSON/CSVで保存してください。Web版は直近12件をメモリに保持し、サーバー終了時に消えます。鍵を結果レポートやアクセスログに書き出しません。表の内容は自動レポートに入ります。CSVは全試行の行データ、JSONは条件・集計を含む完全版です。

## 互換性と変更範囲

QRバージョン12、訂正レベルH、マスク0、マス幅14px、余白6マスは維持。標準1重の1〜8バイトはv0.3と同じ配置・同じパケットです。v0.4で拡張した9バイト以上はv0.3の読み取り対象外です。撮影画像の抽出では中心3×3画素の中央値と二値化を使い、OpenCV側の四隅で認証できなければZXing側の四隅から再抽出します。訂正済みの表QRのマスから裏を推測する処理はしていません。

既存の`/make`、`/plain`、`/read`、`/check`を維持し、測定用APIを追加しました。標準の起動アドレスも127.0.0.1:8765です。鍵処理は互換性のため維持しています。同じ表・鍵を再利用する暗号ストリームの問題があり、機密保護用ではありません。

UI自動操作も再実行したい場合だけ、Node.jsとPlaywrightを追加します（通常のアプリ起動には不要）：

```bash
npm install --no-save playwright
npx playwright install chromium
node tests/ui_check.cjs
```

このテストはアプリのフォルダから実行し、`start.sh`で作成した`.venv`を使います。ポート8766が空いている状態で実行してください。テスト内の「実機記録」はブラウザ動作確認用の模擬入力であり、実機測定には数えません。
