import hashlib, hmac, random, struct, io
import qrcode
from qrcode.constants import ERROR_CORRECT_H
from PIL import Image
import cv2
import numpy as np

VERSION=12
MASK=0
MAX_SECRET_BYTES=8

def base_qr(public):
    q=qrcode.QRCode(version=VERSION,error_correction=ERROR_CORRECT_H,box_size=14,border=6,mask_pattern=MASK)
    q.add_data(public,optimize=0)
    q.make(fit=False)
    return q

def slots():
    q=qrcode.QRCode(version=VERSION,error_correction=ERROR_CORRECT_H)
    n=VERSION*4+17
    q.modules=[[None]*n for _ in range(n)]
    q.modules_count=n
    q.setup_position_probe_pattern(0,0)
    q.setup_position_probe_pattern(n-7,0)
    q.setup_position_probe_pattern(0,n-7)
    q.setup_position_adjust_pattern()
    q.setup_timing_pattern()
    q.setup_type_info(False,MASK)
    q.setup_type_number(False)
    return [(r,c) for r in range(n) for c in range(n) if q.modules[r][c] is None]
DATA_SLOTS=slots()

def positions(public,key,count):
    seed=hashlib.sha256(b'DQR-v1-positions'+public.encode()+key.encode()).digest()
    rnd=random.Random(int.from_bytes(seed,'big'))
    choices=DATA_SLOTS[:]
    rnd.shuffle(choices)
    return choices[:count]

def keystream(public,key,n):
    secret=hashlib.pbkdf2_hmac('sha256',key.encode(),b'DQR-v1'+public.encode(),100000,dklen=32)
    return b''.join(hmac.digest(secret,b'stream'+i.to_bytes(4,'big'),'sha256') for i in range((n+31)//32))[:n],secret

def payload(public,hidden,key):
    body=hidden.encode('utf-8')
    if not (1<=len(body)<=MAX_SECRET_BYTES): raise ValueError('裏メッセージはUTF-8で1〜8バイトにしてください。')
    stream,mac_key=keystream(public,key,len(body))
    enc=bytes(a^b for a,b in zip(body,stream))
    tag=hmac.digest(mac_key,b'tag'+public.encode()+bytes([len(body)])+enc,'sha256')[:8]
    return bytes([len(body)])+enc+tag

def bits_from_bytes(data):
    return [(b>>(7-i))&1 for b in data for i in range(8)]

def make_image(q):
    return q.make_image(fill_color='black',back_color='white').convert('RGB')

def generate(public,hidden,key):
    if not public.strip() or not key: raise ValueError('表の内容と秘密鍵を入力してください。')
    q=base_qr(public)
    packet=payload(public,hidden,key)
    positions_=positions(public,key,8*(1+MAX_SECRET_BYTES+8))
    bits=bits_from_bytes(packet)
    # Embed each bit as the final absolute module value, not as an error marker.
    for (r,c),bit in zip(positions_,bits):
        q.modules[r][c]=bool(bit)
    img=make_image(q)
    decoded=decode(img)
    return img,decoded, sum(q.modules[r][c] != base_qr(public).modules[r][c] for (r,c) in positions_[:len(bits)])

def decode(img):
    arr=cv2.cvtColor(np.array(img.convert('RGB')),cv2.COLOR_RGB2BGR)
    value,points,_=cv2.QRCodeDetector().detectAndDecode(arr)
    return value if points is not None else ''

def read(img,key):
    public=decode(img)
    if not public: raise ValueError('標準QRとして読み取れませんでした。')
    q=base_qr(public)
    # Need original cells, sample from sharp generated image / rectified detected frame.
    arr=np.array(img.convert('L'))
    detector=cv2.QRCodeDetector()
    ok, pts=detector.detect(cv2.cvtColor(np.array(img.convert('RGB')),cv2.COLOR_RGB2BGR))
    if not ok: raise ValueError('QRコードを検出できませんでした。')
    # Warp QR image into a square with known 4-module quiet zone absent.
    n=VERSION*4+17
    corners=np.array(pts[0],dtype=np.float32)
    size=n*10
    dst=np.array([[0,0],[size,0],[size,size],[0,size]],dtype=np.float32)
    warp=cv2.warpPerspective(arr,cv2.getPerspectiveTransform(corners,dst),(size+1,size+1))
    def sample(rc):
        r,c=rc
        x=int((c+.5)*10);y=int((r+.5)*10)
        return 1 if warp[y,x] < 128 else 0
    loc=positions(public,key,8*(1+MAX_SECRET_BYTES+8))
    def take(offset,count):
        bits=[sample(p) for p in loc[offset:offset+count]]
        return bytes(sum(bits[i+j]<<(7-j) for j in range(8)) for i in range(0,len(bits),8))
    length=take(0,8)[0]
    if length<1 or length>MAX_SECRET_BYTES: raise ValueError('裏データがありません。または鍵が違います。')
    raw=take(8,(length+8)*8)
    enc,tag=raw[:-8],raw[-8:]
    stream,mac_key=keystream(public,key,length)
    expected=hmac.digest(mac_key,b'tag'+public.encode()+bytes([length])+enc,'sha256')[:8]
    if not hmac.compare_digest(tag,expected): raise ValueError('裏データがありません。または鍵が違います。')
    try: hidden=bytes(a^b for a,b in zip(enc,stream)).decode('utf-8')
    except UnicodeDecodeError: raise ValueError('裏データが破損しています。')
    return public,hidden
