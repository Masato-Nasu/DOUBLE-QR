import argparse
import csv
import io
import json
import secrets
import threading
import time
from collections import OrderedDict
from functools import wraps
from flask import Flask, render_template, request, send_file, jsonify, abort
from PIL import Image, UnidentifiedImageError
from engine import (base_qr, make_image, read, decode, decode_zxing, verified,
                    png_data, difference_image, REPETITIONS)
import experiments

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 12 * 1024 * 1024
Image.MAX_IMAGE_PIXELS = 16_000_000
jobs = OrderedDict()
job_lock = threading.Lock()
active_job = None


@app.before_request
def same_origin():
    # Permit only same-origin browser mutations, including on the LAN.
    origin=request.headers.get('Origin')
    if request.method=='POST' and origin and origin.rstrip('/') != request.host_url.rstrip('/'):
        abort(403)


@app.after_request
def headers(response):
    response.headers['Cache-Control']='no-store'
    response.headers['X-Content-Type-Options']='nosniff'
    return response


def guarded(fn):
    @wraps(fn)
    def wrapped(*args,**kwargs):
        try: return fn(*args,**kwargs)
        except (ValueError, KeyError, UnidentifiedImageError, Image.DecompressionBombError) as exc:
            return jsonify(error=str(exc)),400
        except Exception as exc:
            return jsonify(error=f'{type(exc).__name__}: {exc}'),400
    return wrapped


def inputs(data):
    public=str(data.get('public',''));hidden=str(data.get('hidden',''));key=str(data.get('key',''))
    rep=int(data.get('repetitions',1))
    if len(public.encode())>150 or len(key)>1024 or len(hidden.encode())>255:
        raise ValueError('入力が長すぎます。表150バイト・裏255バイト・鍵1024文字以内です。')
    if rep not in REPETITIONS: raise ValueError('強度は1、3、5のみです。')
    return public,hidden,key,rep


def upload():
    img=Image.open(request.files['image'].stream)
    if img.width*img.height>16_000_000:
        raise ValueError('画像は1600万画素以下に縮小してください。')
    img.load()
    from PIL import ImageOps
    return ImageOps.exif_transpose(img).convert('RGB')


def png_response(img,name):
    buf=io.BytesIO();img.save(buf,'PNG');buf.seek(0)
    return send_file(buf,mimetype='image/png',download_name=name)


@app.get('/')
def index(): return render_template('index.html')


@app.post('/make')
@guarded
def make():
    public,hidden,key,rep=inputs(request.form)
    a,b,budget,checks=verified(public,hidden,key,rep)
    if not all(checks.values()) or not budget['budget_ok']:
        return jsonify(error='表・裏の検証または訂正余裕の検査を通過しませんでした。裏を短くするか強度を下げてください。',budget=budget,checks=checks),422
    return png_response(make_image(b),'double-qr.png')


@app.post('/plain')
@guarded
def plain():
    public,_,_,_=inputs(request.form)
    if not public.strip(): raise ValueError('表の内容を入力してください。')
    return png_response(make_image(base_qr(public)),'ordinary-qr.png')


@app.post('/read')
@guarded
def read_file():
    public,hidden=read(upload(),request.form.get('key',''),int(request.form.get('repetitions',1)))
    return jsonify(public=public,hidden=hidden)


@app.post('/check')
@guarded
def check():
    img=upload()
    return jsonify(public=decode(img) or '(通常QRとして読めませんでした)',zxing=decode_zxing(img))


@app.post('/api/analyze')
@guarded
def analyze():
    public,hidden,key,rep=inputs(request.form)
    a,b,budget,checks=verified(public,hidden,key,rep)
    accepted=all(checks.values()) and budget['budget_ok']
    return jsonify(accepted=accepted,budget=budget,checks=checks,public=public,
                   hidden_bytes=len(hidden.encode()),repetitions=rep,
                   images=dict(plain=png_data(make_image(a)),double=png_data(make_image(b)),diff=png_data(difference_image(a,b))),
                   status='保存可：自動検査を通過。実機は別途確認してください。' if accepted else '検査不合格：診断表示のみ。裏を短くするか強度を下げてください。')


@app.post('/api/jobs')
@guarded
def start_job():
    global active_job
    data=request.get_json(force=True)
    public,hidden,key,rep=inputs(data)
    if not public.strip() or not key: raise ValueError('表と鍵を入力してください。')
    kind=data.get('kind')
    seed=int(data.get('seed',20261010))
    if not 0<=seed<=2**32-100000: raise ValueError('seedが範囲外です。')
    if kind=='benchmark':
        trials=int(data.get('trials',3))
        if not 1<=trials<=20: raise ValueError('試行回数は1〜20です。')
        task=lambda progress:experiments.benchmark(public,hidden,key,rep,trials,seed,progress)
    elif kind=='capacity':
        maximum=int(data.get('max_bytes',32));samples=int(data.get('samples',2))
        if not 1<=maximum<=255 or not 1<=samples<=3: raise ValueError('容量1〜255、標本数1〜3です。')
        task=lambda progress:experiments.capacity(public,key,rep,maximum,samples,seed,progress)
    elif kind=='statistics':
        count=int(data.get('count',24))
        if not 8<=count<=100: raise ValueError('標本数は8〜100です。')
        task=lambda progress:experiments.statistics(public,hidden,key,rep,count,seed,progress)
    else: raise ValueError('測定種別が不正です。')
    with job_lock:
        if active_job:
            return jsonify(error='別の測定が進行中です。完了後に実行してください。'),409
        job_id=secrets.token_urlsafe(24)
        while len(jobs)>=12: jobs.popitem(last=False)
        jobs[job_id]=dict(status='running',done=0,total=0,kind=kind,started=time.time())
        active_job=job_id
    def progress(done,total):
        with job_lock: jobs[job_id].update(done=done,total=total)
    def run():
        global active_job
        try:
            report=task(progress)
            with job_lock: jobs[job_id].update(status='complete',report=report)
        except Exception as exc:
            with job_lock: jobs[job_id].update(status='error',error=f'{type(exc).__name__}: {exc}')
        finally:
            with job_lock: active_job=None
    threading.Thread(target=run,daemon=True).start()
    return jsonify(id=job_id),202


@app.get('/api/jobs/<job_id>')
def get_job(job_id):
    with job_lock:
        if job_id not in jobs: return jsonify(error='測定結果がありません。再実行してください。'),404
        return jsonify(jobs[job_id])


@app.get('/api/jobs/<job_id>/download')
def download_job(job_id):
    with job_lock:
        job=jobs.get(job_id,{})
        report=job.get('report')
    if not report: return jsonify(error='結果はまだありません。'),404
    if request.args.get('format')=='csv':
        rows=report['rows'];columns=sorted(set().union(*(r.keys() for r in rows)))
        out=io.StringIO();writer=csv.DictWriter(out,fieldnames=columns);writer.writeheader()
        for row in rows:
            writer.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else v for k,v in row.items()})
        raw=out.getvalue().encode('utf-8-sig');name=report['kind']+'.csv';mime='text/csv'
    else:
        raw=json.dumps(report,ensure_ascii=False,indent=2).encode();name=report['kind']+'.json';mime='application/json'
    return send_file(io.BytesIO(raw),mimetype=mime,as_attachment=True,download_name=name)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--lan',action='store_true',help='同じWi-Fiのスマートフォンから接続する')
    parser.add_argument('--port',type=int,default=8765)
    args=parser.parse_args()
    print(f'DOUBLE QR v0.4: http://127.0.0.1:{args.port}')
    if args.lan: print('LAN接続を有効にしました。スマートフォンでは http://PCのLANアドレス:'+str(args.port)+' を開いてください。')
    app.run(host='0.0.0.0' if args.lan else '127.0.0.1',port=args.port,debug=False,threaded=True)
