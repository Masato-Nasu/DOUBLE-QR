#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if ! command -v python3 >/dev/null 2>&1; then
  echo 'Python 3が必要です：sudo apt install python3 python3-venv'
  exit 1
fi
if [[ ! -x .venv/bin/python ]]; then
  if ! python3 -m venv .venv; then
    echo '次を実行してから再試行してください：sudo apt install python3-venv'
    exit 1
  fi
fi
fingerprint="$(sha256sum requirements.txt | cut -d ' ' -f 1)"
installed="$(cat .venv/double-qr-requirements.sha256 2>/dev/null || true)"
if [[ "$fingerprint" != "$installed" ]]; then
  .venv/bin/python -m pip install -r requirements.txt
  printf '%s\n' "$fingerprint" > .venv/double-qr-requirements.sha256
fi
if [[ " ${*} " == *' --lan '* ]]; then
  echo '同じWi-Fiのスマートフォンでは、下記LANアドレスとポート8765を使用します。'
  hostname -I || true
fi
exec .venv/bin/python app.py "$@"
